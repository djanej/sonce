---
title: Compatibility Test
date: 2025-09-18
slug: "compatibility-test"
author: Automation
summary: Test generation
tags: [news, test]
image: "/static/uploads/news/2025/09/2025-09-18-compatibility-test-hero.jpg"
imageAlt: Compatibility Test
draft: false
---

Hello world
